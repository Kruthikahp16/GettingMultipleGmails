package com.mail.component;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;

@Component
@Entity
public class Email {
	private String sender;
	private String subject;

	public Email(String sender, String subject) {
		this.sender = sender;
		this.subject = subject;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
}
