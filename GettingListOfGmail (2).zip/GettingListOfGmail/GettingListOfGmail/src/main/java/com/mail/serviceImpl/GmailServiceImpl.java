package com.mail.serviceImpl;

import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePartHeader;
import com.mail.service.GmailService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class GmailServiceImpl implements GmailService {

	private static final String USER = "me";
	private static final String MESSAGE_FORMAT = "full";
	private static final long MAX_RESULTS = 200L;

	@Value("${gmail.credentials.path}")
	private String credentialsPath;

	private Gmail gmailService;

	@Override
	public List<com.mail.component.Email> getLast200Emails() throws IOException {
		List<com.mail.component.Email> emails = new ArrayList<>();
		Gmail.Users.Messages.List request = gmailService.users().messages().list(USER).setMaxResults(MAX_RESULTS);
		List<Message> messages = request.execute().getMessages();

		for (Message message : messages) {
			Message fullMessage = gmailService.users().messages().get(USER, message.getId()).setFormat(MESSAGE_FORMAT)
					.execute();
			String sender = getEmailAddress(fullMessage, "From");
			emails.add(new com.mail.component.Email(sender, sender));
		}
		return emails;
	}

	private String getEmailAddress(Message message, String headerName) {
		String emailAddress = null;
		List<MessagePartHeader> headers = message.getPayload().getHeaders();
		for (MessagePartHeader header : headers) {
			if (header.getName().equals(headerName)) {
				emailAddress = header.getValue();
				break;
			}
		}
		return emailAddress;
	}
}
