// EmailService.java
package com.mail.service;

import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Service;
import com.mail.component.Email;

@Service
public interface GmailService {
    List<Email> getLast200Emails() throws IOException;
}
